$(document).ready(function(){

  $(".scan").click(function(){
    cordova.plugins.barcodeScanner.scan(
        function (result) {
            alert("We got a barcode\n" +
                  "Result: " + result.text + "\n" +
                  "Format: " + result.format + "\n" +
                  "Cancelled: " + result.cancelled);
        },
        function (error) {
            console.log("Scanning failed: " + error);
        }
     );

  });

});
